# KR Owner Project

Собственный клиент/серверный прототип с аккаунтом владельца и админ-системой.

## Что уже есть
- Android-клиент с авторизацией.
- Сервер FastAPI + SQLite.
- Роль `owner` и уровни администраторов.
- `/makeadmin`, `/unadmin`, `/kick`, `/ban`, `/mute`, `/tp`, `/goto`, `/gethere`, `/sethp`, `/setarmor`, `/give`, `/setmoney`, `/spawn`.
- Audit log.
- GitHub Actions для автоматической сборки APK.
- Dockerfile для запуска серверного API.

## Быстрый запуск с телефона
1. Создай репозиторий GitHub.
2. Загрузи содержимое этого проекта.
3. GitHub → Actions → Build Android APK → Run workflow.
4. Скачай artifact `kr-owner-debug-apk`.

## Важно
Это не является копией чужого коммерческого клиента или серверной инфраструктуры. Это собственная основа, которую можно расширять игровым клиентом и сервером.

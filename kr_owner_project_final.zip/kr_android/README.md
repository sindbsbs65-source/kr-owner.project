# KR Owner Client — cloud build

Это Android-клиент для собственного сервера с авторизацией и OWNER/админ-системой.

## Сборка без ПК
1. Создайте пустой GitHub repository.
2. Загрузите **содержимое этой папки** в repository.
3. Откройте Actions → Build APK → Run workflow.
4. После завершения откройте workflow run → Artifacts → `kr-owner-debug-apk`.
5. Скачайте `app-debug.apk` на Android.

## Важно
Это не 1:1 копия чужой игры и не содержит оригинальные GTA/SA-MP бинарники. Это самостоятельная клиентская основа для вашего сервера.

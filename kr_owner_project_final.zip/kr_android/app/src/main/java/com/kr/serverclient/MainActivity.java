package com.kr.serverclient;

import android.app.*;
import android.os.*;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    EditText server, login, password; TextView status; LinearLayout root; String token="";
    @Override public void onCreate(Bundle b){ super.onCreate(b); showLogin(); }
    TextView t(String s,int z){ TextView x=new TextView(this); x.setText(s); x.setTextSize(z); x.setTextColor(Color.WHITE); x.setPadding(0,12,0,12); return x; }
    EditText e(String s,String hint){ EditText x=new EditText(this); x.setText(s); x.setHint(hint); x.setTextColor(Color.WHITE); x.setHintTextColor(Color.GRAY); return x; }
    void base(){ root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(48,32,48,32); root.setBackgroundColor(Color.rgb(14,17,22)); setContentView(root); }
    void showLogin(){ base(); root.addView(t("KR SERVER",28)); root.addView(t("Вход в аккаунт",15));
        server=e("http://10.0.2.2:8080","Адрес API"); login=e("creator","Логин"); password=e("","Пароль"); password.setInputType(129);
        root.addView(server); root.addView(login); root.addView(password); Button b=new Button(this); b.setText("ВОЙТИ"); root.addView(b);
        status=t("Не подключено",14); status.setTextColor(Color.GRAY); root.addView(status); b.setOnClickListener(v->auth()); }
    void auth(){ final String baseUrl=server.getText().toString().trim(); final String u=login.getText().toString().trim(); final String p=password.getText().toString(); status.setText("Подключение...");
        new Thread(()->{ try{ String body="{\"login\":\""+esc(u)+"\",\"password\":\""+esc(p)+"\"}"; HttpURLConnection c=post(baseUrl+"/auth/login",body,null); int code=c.getResponseCode(); String r=read(code>=400?c.getErrorStream():c.getInputStream());
            if(code>=200&&code<300){ token=field(r,"token"); String role=field(r,"role"); runOnUiThread(()->showPanel(baseUrl,field(r,"login"),role)); } else runOnUiThread(()->status.setText("HTTP "+code+": "+r));
        }catch(Exception e){runOnUiThread(()->status.setText("Ошибка: "+e.getMessage()));}}).start(); }
    void showPanel(String baseUrl,String who,String role){ base(); root.addView(t("Панель сервера",26)); root.addView(t("Игрок: "+who+"\nРоль: "+role,16));
        Button me=new Button(this); me.setText("ПРОВЕРИТЬ ПРОФИЛЬ"); root.addView(me);
        Button admins=new Button(this); admins.setText("СПИСОК АДМИНИСТРАТОРОВ"); root.addView(admins);
        EditText cmd=e("/makeadmin player admin","Команда"); root.addView(cmd); Button send=new Button(this); send.setText("ВЫПОЛНИТЬ КОМАНДУ"); root.addView(send);
        status=t("Готово",14); status.setTextColor(Color.LTGRAY); root.addView(status);
        me.setOnClickListener(v->get(baseUrl+"/me",status)); admins.setOnClickListener(v->get(baseUrl+"/admins",status)); send.setOnClickListener(v->command(baseUrl,cmd.getText().toString())); }
    void get(String url,TextView out){ new Thread(()->{try{HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestProperty("Authorization","Bearer "+token); int code=c.getResponseCode(); String r=read(code>=400?c.getErrorStream():c.getInputStream()); runOnUiThread(()->out.setText("HTTP "+code+": "+r));}catch(Exception e){runOnUiThread(()->out.setText("Ошибка: "+e.getMessage()));}}).start(); }
    void command(String baseUrl,String command){ new Thread(()->{try{String body="{\"command\":\""+esc(command)+"\"}"; HttpURLConnection c=post(baseUrl+"/command",body,token); int code=c.getResponseCode(); String r=read(code>=400?c.getErrorStream():c.getInputStream()); runOnUiThread(()->status.setText("HTTP "+code+": "+r));}catch(Exception e){runOnUiThread(()->status.setText("Ошибка: "+e.getMessage()));}}).start(); }
    HttpURLConnection post(String url,String body,String auth)throws Exception{ HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection(); c.setRequestMethod("POST"); c.setRequestProperty("Content-Type","application/json"); if(auth!=null)c.setRequestProperty("Authorization","Bearer "+auth); c.setDoOutput(true); try(OutputStream o=c.getOutputStream()){o.write(body.getBytes(StandardCharsets.UTF_8));} return c; }
    String field(String json,String key){String p="\""+key+"\""; int i=json.indexOf(p); if(i<0)return ""; i=json.indexOf(':',i)+1; while(i<json.length()&&Character.isWhitespace(json.charAt(i)))i++; if(i<json.length()&&json.charAt(i)=='\"'){int j=json.indexOf('\"',i+1);return j>i?json.substring(i+1,j):"";} int j=i;while(j<json.length()&&",}".indexOf(json.charAt(j))<0)j++;return json.substring(i,j).trim();}
    String read(InputStream i)throws Exception{if(i==null)return "";ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[2048];int n;while((n=i.read(x))!=-1)b.write(x,0,n);return b.toString("UTF-8");}
    String esc(String s){return s.replace("\\","\\\\").replace("\"","\\\"");}
}

# KR Server Core

Серверная основа для собственного игрового проекта: аккаунты, владелец, уровни администрации, команды и аудит.

## Запуск

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8080
```

При первом запуске создаётся `OWNER_CREDENTIALS.txt` с аккаунтом владельца.

## Что уже есть

- owner/admin role hierarchy
- выдача и снятие ролей
- login/session tokens
- `/kick`, `/ban`, `/mute`
- `/tp`, `/goto`, `/gethere`
- `/sethp`, `/setarmor`
- `/give`, `/setmoney`, `/spawn`
- `/makeadmin`, `/unadmin`
- журнал действий администрации
- SQLite без внешней БД

## Важно

Это серверное ядро, а не готовый клон GTA/SA-MP. Игровой транспорт и игровые действия должны быть подключены к конкретному серверному движку/протоколу. Оригинальный APK пользователя содержит нативные компоненты GTA/SA-MP, но их серверная логика не является частью Android APK.

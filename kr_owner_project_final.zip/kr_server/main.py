from fastapi import FastAPI, HTTPException, Header
from pydantic import BaseModel, Field
import sqlite3, hashlib, secrets, time, shlex
from pathlib import Path

DB = Path(__file__).with_name('server.db')
app = FastAPI(title='KR Server Core', version='0.1.0')

ROLES = {'player': 0, 'helper': 1, 'moderator': 2, 'admin': 3, 'senior_admin': 4, 'owner': 5}

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init():
    c = db()
    c.executescript('''
    CREATE TABLE IF NOT EXISTS accounts(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      login TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'player',
      created_at INTEGER NOT NULL,
      last_login INTEGER
    );
    CREATE TABLE IF NOT EXISTS sessions(
      token TEXT PRIMARY KEY,
      account_id INTEGER NOT NULL,
      created_at INTEGER NOT NULL,
      FOREIGN KEY(account_id) REFERENCES accounts(id)
    );
    CREATE TABLE IF NOT EXISTS audit(
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      actor_id INTEGER NOT NULL,
      action TEXT NOT NULL,
      target TEXT,
      payload TEXT,
      created_at INTEGER NOT NULL
    );
    ''')
    if not c.execute('SELECT 1 FROM accounts WHERE role="owner" LIMIT 1').fetchone():
        pwd = secrets.token_urlsafe(12)
        h = hashlib.sha256(pwd.encode()).hexdigest()
        c.execute('INSERT INTO accounts(login,password_hash,role,created_at) VALUES(?,?,?,?)', ('creator', h, 'owner', int(time.time())))
        c.commit()
        Path(__file__).with_name('OWNER_CREDENTIALS.txt').write_text(f'login=creator\npassword={pwd}\n', encoding='utf-8')
    c.close()
init()

class Login(BaseModel):
    login: str
    password: str
class AdminSet(BaseModel):
    login: str
    role: str = Field(pattern='^(player|helper|moderator|admin|senior_admin|owner)$')
class Command(BaseModel):
    command: str


def actor(auth):
    if not auth or not auth.startswith('Bearer '): raise HTTPException(401, 'Unauthorized')
    t = auth[7:]
    c=db(); r=c.execute('SELECT a.* FROM sessions s JOIN accounts a ON a.id=s.account_id WHERE s.token=?',(t,)).fetchone(); c.close()
    if not r: raise HTTPException(401, 'Invalid token')
    return r

def require(r, minimum):
    if ROLES[r['role']] < ROLES[minimum]: raise HTTPException(403, 'Insufficient privileges')

@app.get('/health')
def health(): return {'ok': True, 'service':'kr-server-core'}

@app.post('/auth/login')
def login(x: Login):
    c=db(); r=c.execute('SELECT * FROM accounts WHERE login=?',(x.login,)).fetchone()
    if not r or hashlib.sha256(x.password.encode()).hexdigest()!=r['password_hash']: raise HTTPException(401,'Bad credentials')
    token=secrets.token_urlsafe(32); now=int(time.time())
    c.execute('INSERT INTO sessions(token,account_id,created_at) VALUES(?,?,?)',(token,r['id'],now)); c.execute('UPDATE accounts SET last_login=? WHERE id=?',(now,r['id'])); c.commit(); c.close()
    return {'token':token,'login':r['login'],'role':r['role']}

@app.get('/me')
def me(authorization: str|None = Header(default=None)):
    r=actor(authorization); return {'id':r['id'],'login':r['login'],'role':r['role'],'role_level':ROLES[r['role']]}

@app.get('/admins')
def admins(authorization: str|None = Header(default=None)):
    r=actor(authorization); require(r,'admin')
    c=db(); rows=c.execute('SELECT id,login,role,created_at,last_login FROM accounts WHERE role != "player" ORDER BY role DESC, login').fetchall(); c.close()
    return [dict(x) for x in rows]

@app.post('/admins/set')
def set_admin(x: AdminSet, authorization: str|None = Header(default=None)):
    r=actor(authorization); require(r,'owner')
    c=db(); target=c.execute('SELECT * FROM accounts WHERE login=?',(x.login,)).fetchone()
    if not target: c.close(); raise HTTPException(404,'Account not found')
    if target['id']==r['id'] and x.role!='owner': c.close(); raise HTTPException(400,'Owner cannot demote self')
    c.execute('UPDATE accounts SET role=? WHERE id=?',(x.role,target['id']))
    c.execute('INSERT INTO audit(actor_id,action,target,payload,created_at) VALUES(?,?,?,?,?)',(r['id'],'set_role',x.login,x.role,int(time.time())))
    c.commit(); c.close(); return {'ok':True,'login':x.login,'role':x.role}

@app.get('/audit')
def audit(authorization: str|None = Header(default=None)):
    r=actor(authorization); require(r,'admin')
    c=db(); rows=c.execute('SELECT * FROM audit ORDER BY id DESC LIMIT 200').fetchall(); c.close(); return [dict(x) for x in rows]

@app.post('/command')
def command(x: Command, authorization: str|None = Header(default=None)):
    r=actor(authorization); require(r,'moderator')
    try: parts=shlex.split(x.command)
    except ValueError: raise HTTPException(400,'Invalid command syntax')
    if not parts: raise HTTPException(400,'Empty command')
    cmd=parts[0].lstrip('/').lower(); args=parts[1:]
    allowed={
      'kick':'moderator','ban':'moderator','mute':'moderator','unmute':'moderator',
      'tp':'admin','goto':'admin','gethere':'admin','sethp':'admin','setarmor':'admin',
      'give':'admin','setmoney':'admin','spawn':'admin',
      'makeadmin':'owner','unadmin':'owner'
    }
    if cmd not in allowed: raise HTTPException(400,'Command not implemented')
    require(r, allowed[cmd])
    c=db(); c.execute('INSERT INTO audit(actor_id,action,target,payload,created_at) VALUES(?,?,?,?,?)',(r['id'],cmd,args[0] if args else None,' '.join(args),int(time.time()))); c.commit(); c.close()
    return {'ok':True,'command':cmd,'args':args,'message':'Command accepted by server core; bind it to the game transport next.'}
